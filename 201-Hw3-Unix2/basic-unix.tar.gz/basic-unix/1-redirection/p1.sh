#!/bin/sh
# TODO: modify the following line so that the output of the following command is saved to a file named "linecount"
wc -l $0
