#!/bin/sh
# TODO: modify the following line so that the output of the following command is **appended** to a file named "time-log"
date +%D
