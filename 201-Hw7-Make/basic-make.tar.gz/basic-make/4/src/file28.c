int function28(void) { return 28; }
