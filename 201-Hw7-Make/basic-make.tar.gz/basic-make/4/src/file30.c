int function30(void) { return 30; }
