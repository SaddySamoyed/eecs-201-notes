int function18(void) { return 18; }
