int function22(void) { return 22; }
