int function23(void) { return 23; }
