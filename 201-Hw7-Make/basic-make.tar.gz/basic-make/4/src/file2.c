int function2(void) { return 2; }
