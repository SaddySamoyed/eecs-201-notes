int function1(void) { return 1; }
