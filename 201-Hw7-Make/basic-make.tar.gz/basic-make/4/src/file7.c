int function7(void) { return 7; }
