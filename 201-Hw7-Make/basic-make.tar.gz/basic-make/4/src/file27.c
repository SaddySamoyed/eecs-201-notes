int function27(void) { return 27; }
