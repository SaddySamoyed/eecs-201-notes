int function12(void) { return 12; }
