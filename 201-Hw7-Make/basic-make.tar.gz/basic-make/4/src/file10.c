int function10(void) { return 10; }
