int function25(void) { return 25; }
