int function3(void) { return 3; }
