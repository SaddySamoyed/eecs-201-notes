int function4(void) { return 4; }
