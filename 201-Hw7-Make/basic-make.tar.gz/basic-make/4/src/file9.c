int function9(void) { return 9; }
