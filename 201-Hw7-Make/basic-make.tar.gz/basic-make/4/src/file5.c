int function5(void) { return 5; }
