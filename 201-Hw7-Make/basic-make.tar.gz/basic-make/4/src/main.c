#include <stdio.h>

extern int function1(void);
extern int function2(void);
extern int function3(void);
extern int function4(void);
extern int function5(void);
extern int function6(void);
extern int function7(void);
extern int function8(void);
extern int function9(void);
extern int function10(void);
extern int function11(void);
extern int function12(void);
extern int function13(void);
extern int function14(void);
extern int function15(void);
extern int function16(void);
extern int function17(void);
extern int function18(void);
extern int function19(void);
extern int function20(void);
extern int function21(void);
extern int function22(void);
extern int function23(void);
extern int function24(void);
extern int function25(void);
extern int function26(void);
extern int function27(void);
extern int function28(void);
extern int function29(void);
extern int function30(void);

int main(void)
{
    printf("%d\n",
            function1() +
            function2() +
            function3() +
            function4() +
            function5() +
            function6() +
            function7() +
            function8() +
            function9() +
            function10() +
            function11() +
            function12() +
            function13() +
            function14() +
            function15() +
            function16() +
            function17() +
            function18() +
            function19() +
            function20() +
            function21() +
            function22() +
            function23() +
            function24() +
            function25() +
            function26() +
            function27() +
            function28() +
            function29() +
            function30());
    return 0;
}
