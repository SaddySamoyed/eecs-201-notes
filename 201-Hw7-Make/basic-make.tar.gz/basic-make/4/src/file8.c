int function8(void) { return 8; }
