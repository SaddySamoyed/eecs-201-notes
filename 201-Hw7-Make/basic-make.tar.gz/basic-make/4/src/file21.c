int function21(void) { return 21; }
