int function26(void) { return 26; }
