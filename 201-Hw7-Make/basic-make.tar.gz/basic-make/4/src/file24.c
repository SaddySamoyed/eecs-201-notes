int function24(void) { return 24; }
