int function16(void) { return 16; }
