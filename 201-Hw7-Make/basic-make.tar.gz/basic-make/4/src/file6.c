int function6(void) { return 6; }
