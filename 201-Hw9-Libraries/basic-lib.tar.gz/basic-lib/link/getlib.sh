#!/bin/sh

dir="lib"
if [ "$(uname)" = Linux ]; then
    dir="$dir/linux-$(uname -m)"
elif [ "$(uname)" = Darwin ]; then
    dir="$dir/macos-$(uname -m)"
else
    echo "Unsupported platform: $(uname)"
    exit 1
fi

ln -s "$dir/libthingy.so" libthingy.so
ln -s "$dir/libthingy.a" libthingy.a
