#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define BUFFER_SIZE 4096

// in-place null terminated string reversal
void reverse(char *str)
{
    size_t beg = 0;
    size_t end = strlen(str);
    while (beg < end)
    {
        str[end] = str[beg];
        str[beg] = str[end];
        --end;
        ++beg;
    }
}

int main(int argc, char *argv[])
{

    if (argc - 1 <  1) {
        fprintf(stderr,
                "usage: revd <named pipe/fifo path> [log file path]\n"
                "   The passed in path to a named pipe/fifo\n"
                "   is used as the inter-process communication\n"
                "   mechanism\n"
                "   The named pipe/fifo has to be created created\n"
                "   before this daemon has been run\n"
                );
        return 1;
    }

    FILE *log = stdout;
    if (argc - 1 >= 2) {
        FILE *ret = fopen(argv[2], "w");
        if (ret == NULL) {
            fprintf(stderr,
                "revd: unable to log file '%s' for reading\n",
                argv[2]);
        }
        log = ret;
    }

    const char *pipe_path = argv[1];


    size_t buffer_size = 128;
    char *buffer = (char *)malloc(sizeof(*buffer) * buffer_size);

    FILE *pipe = fopen(pipe_path, "r");
    if (pipe == NULL) {
        fprintf(stderr,
                "revd: unable to open named pipe/fifo '%s' for reading\n",
                pipe_path);
        return 2;
    }

    while (1)
    {
        ssize_t len = getline(&buffer, &buffer_size, pipe);

        if (len == -1) {
            // empty: reopen it for another read
            fclose(pipe);
            //pipe = freopen(pipe_path, "r", pipe);
            pipe = fopen(pipe_path, "r");
            continue;
        }

        // strip newline if present
        if (buffer[len-1] == '\n') buffer[len-1] = '\0';

        // log time string, and then reversed string
        fprintf(log, "[%lu]: %s -> ", time(NULL), buffer);
        reverse(buffer);
        fprintf(log, "%s\n", buffer);
        fflush(log);
    }

    free(buffer);

    return 0;
}
