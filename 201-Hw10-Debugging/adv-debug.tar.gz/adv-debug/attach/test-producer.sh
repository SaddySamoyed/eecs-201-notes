#!/bin/bash
dict=/usr/share/dict/words
num_words=$(cat $dict | wc -l)
while true; do
    line_num=$(($RANDOM % $num_words))
    sed -n "${line_num}p" "$dict" > "./fifo"
    sleep 1
done
