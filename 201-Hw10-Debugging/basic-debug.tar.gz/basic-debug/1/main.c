#include <stdlib.h>
#include <stdio.h>
#include "helper.h"

int main(int argc, char *argv[])
{
    if (argc - 1 < 1) {
        fprintf(stderr,
            "usage: seqmean <integer>\n"
            "  Calculates and prints out the mean of\n"
            "  the numbers from 1 to <integer>\n"
        );

        return 1;
    }

    int n;
    if (sscanf(argv[1], "%d", &n) == 0) {
        fprintf(stderr, "seqmean: argument '%s' was not an integer\n", argv[1]);
        return 2;
    }

    data d;

    data_ctor(&d, n);
    for (int i = 0; i < d.size; ++i) {
        d.buffer[i] = (float) i;
    }

    stats s = data_calc_stats(NULL);
    data_dtor(&d);

    printf("mean = %f\n", s.mean);

    return 0;
}
