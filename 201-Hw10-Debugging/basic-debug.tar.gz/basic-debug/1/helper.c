#include <stdlib.h>
#include "helper.h"

void data_ctor(data *d, int size)
{
    d->size = size;
    d->buffer = (float *) malloc(sizeof(*d->buffer) * size);
}

void data_dtor(data *d)
{
    free(d->buffer);
}

stats data_calc_stats(const data *d)
{
    stats out;

    float sum = 0.0f;
    for (int i = 0; i < d->size; ++i) {
        sum += d->buffer[i];
    }

    out.mean = sum / (float)(d->size);

    return out;
}
