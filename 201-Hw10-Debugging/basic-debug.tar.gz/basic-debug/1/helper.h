#ifndef __HELPER_H__
#define __HELPER_H__

#ifdef __cplusplus
extern "C" {
#endif

typedef struct data_
{
    float *buffer;
    int size;
} data;

typedef struct stats_
{
    float mean;
} stats;

/**
 * Construct a "data" object
 * @param d     pointer to data object
 * @param size  size of data buffer
 */
void data_ctor(data *d, int size);

/**
 * Destruct a "data" object
 * @param d     pointer to data object
 */
void data_dtor(data *d);

/**
 * Calculate stats on some data
 * @param d     pointer to data object
 * @return statistics object
 */
stats data_calc_stats(const data *d);

#ifdef __cplusplus
}
#endif

#endif//__HELPER_H__
