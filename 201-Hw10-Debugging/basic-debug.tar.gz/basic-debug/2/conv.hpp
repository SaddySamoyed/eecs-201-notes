#ifndef __CONV_HPP__
#define __CONV_HPP__

#include <ostream>
#include <vector>

class Signal
{
public:
    Signal(int n);
    ~Signal();

    Signal convolve(Signal &filter);
    int size(void) const {return this->m_size;};
    double &operator[](int n);
    const double &operator[](int n) const;

private:
    double *m_buffer;
    int m_size;
};

std::ostream &operator<<(std::ostream &os, const Signal &signal);

#endif//__CONV_HPP__
