#include <iostream>
#include "conv.hpp"

int main(int argc, char *argv[])
{
    constexpr int size = 3;
    Signal x(size);
    Signal h(size);

    // let both be rect filters
    for (int i = 0; i <= x.size(); ++i) x[i] = 1.0;
    for (int i = 0; i < h.size(); ++i) h[i] = 1.0;

    Signal y = x.convolve(h);
    std::cout << "n = " << y.size() << std::endl;
    std::cout << y << std::endl;

    return 0;
}
