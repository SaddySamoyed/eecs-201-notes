#include "conv.hpp"

Signal::Signal(int n)
{
    this->m_buffer = new double[n];
    this->m_size = n;
}

Signal::~Signal()
{
}

double &Signal::operator[](int n)
{
    return this->m_buffer[n];
}

const double &Signal::operator[](int n) const
{
    return this->m_buffer[n];
}

Signal Signal::convolve(Signal &h)
{
    Signal &x = *this;
    int xN = x.size();
    int hN = h.size();
    int newSize = xN + hN - 1;
    Signal out(newSize);

    for (int n = 0; n < newSize; ++n) {
        double sum = 0.0;

        for (int xI = 0, hI = n; xI < xN; ++xI, --hI) {
            if (0 <= hI && hI <= hN)
                sum += x[xI] * h[hI];
        }

        out[n] = sum / (double) newSize;
    }

    return out;
}

std::ostream &operator<<(std::ostream &os, const Signal &signal)
{
    for (int i = 0; i < signal.size() - 1; ++i) {
        os << signal[i] << ' ';
    }
    os << signal[signal.size() - 1];
    return os;
}
